document.addEventListener('DOMContentLoaded', () => {
  const grid = document.getElementById('productsGrid');
  const countSpan = document.getElementById('totalCount');
  const emptyState = document.getElementById('emptyState');
  const searchInput = document.getElementById('searchInput');
  const refreshBtn = document.getElementById('refreshBtn');
// я это обсуфицировать даже не буду
  let allProducts = [];

  async function loadData() {
    const data = await chrome.storage.local.get("parserSnapshot");
    const snapshot = data.parserSnapshot;
    
    if (snapshot && snapshot.results && snapshot.results.length > 0) {
      allProducts = [...snapshot.results].reverse(); 
      renderProducts(allProducts);
    } else {
      allProducts = [];
      showEmptyState();
    }
  }


  function renderProducts(products) {
    grid.innerHTML = ''; // Очищаем сетку
    countSpan.textContent = products.length;

    if (products.length === 0) {
      showEmptyState();
      return;
    }

    emptyState.style.display = 'none';
    grid.style.display = 'grid';

    products.forEach(item => {
      const card = document.createElement('div');
      card.className = 'product-card';

      const imgSrc = item.imageUrl && item.imageUrl.startsWith('http') 
        ? item.imageUrl 
        : 'https://via.placeholder.com/300x200?text=No+Image';

      let siteName = item.site;
      try { siteName = new URL(item.site).hostname.replace('www.', ''); } catch(e) {}

      card.innerHTML = `
        <img src="${imgSrc}" alt="Product Image" class="product-image" loading="lazy" onerror="this.src='https://via.placeholder.com/300x200?text=Error'">
        <div class="product-info">
          <div class="product-site">${siteName}</div>
          <div class="product-title" title="${item.title}">${item.title}</div>
          <div class="product-footer">
            <div class="product-price">${item.price || 'Цена не указана'}</div>
            <a href="${item.itemUrl}" target="_blank" class="product-link">Открыть ↗</a>
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
  }

  function showEmptyState() {
    grid.style.display = 'none';
    emptyState.style.display = 'block';
    countSpan.textContent = '0';
  }

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    const filtered = allProducts.filter(item => 
      item.title.toLowerCase().includes(query) || 
      item.site.toLowerCase().includes(query)
    );
    renderProducts(filtered);
  });


  refreshBtn.addEventListener('click', loadData);


  loadData();
});